---
name: Bug report
about: Report a reproducible issue
title: "[Bug] "
labels: bug
assignees: ""
---

## What happened?

## Steps to reproduce
1.
2.
3.

## Expected behaviour

## Environment
- Browser / device:
- App version or commit:

## Screenshots or logs

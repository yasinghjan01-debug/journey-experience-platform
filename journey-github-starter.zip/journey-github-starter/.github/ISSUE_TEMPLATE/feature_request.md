---
name: Feature request
about: Propose a user-focused improvement
title: "[Feature] "
labels: enhancement
assignees: ""
---

## User problem
Who is experiencing the problem, and what are they trying to do?

## Proposed solution
Describe the smallest useful solution.

## Acceptance criteria
- [ ] 
- [ ] 

## Out of scope
What should this change not include?
